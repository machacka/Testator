package com.example.cloudedge4tasker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TaskerCommandReceiver: BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val cmd = intent.getStringExtra("command") ?: return
        val cameraId = intent.getStringExtra("cameraId")

        // Exécuter commande en background
        CoroutineScope(Dispatchers.IO).launch {
            when(cmd) {
                "ENABLE_ALL" -> { /* appel API pour activer tout */ }
                "DISABLE_ALL" -> { }
                "START_SIREN" -> { }
            }
        }
    }
}
