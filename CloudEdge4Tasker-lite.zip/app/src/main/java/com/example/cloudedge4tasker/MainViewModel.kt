package com.example.cloudedge4tasker

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class UiState(val logged: Boolean = false, val cameras: List<Camera> = emptyList())

class MainViewModel: ViewModel() {
    private val _uiState = MutableStateFlow(UiState())
    val uiState = _uiState.asStateFlow()

    fun login(country:String, prefix:String, email:String, pw:String){
        viewModelScope.launch {
            // demo fake token + list
            _uiState.value = UiState(logged = true, cameras = listOf(Camera("cam1","Entrée", true, true), Camera("cam2","Bureau", false, true)))
        }
    }

    fun setMotion(cameraId:String, enabled:Boolean){
        // fake: no-op
    }

    fun downloadLastImage(cameraId:String){
        // fake: no-op
    }
}
