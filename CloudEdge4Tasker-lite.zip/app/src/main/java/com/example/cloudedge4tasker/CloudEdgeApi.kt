package com.example.cloudedge4tasker

// Squelette de wrapper API. À implémenter avec Retrofit/SDK réel.
object CloudEdgeApi {
    suspend fun login(country:String, prefix:String, email:String, password:String): Result<String> {
        return Result.success("FAKE_TOKEN")
    }
    suspend fun listCameras(token:String): List<Camera> = listOf()
    suspend fun setMotionEnabled(token:String, cameraId:String, enabled:Boolean): Boolean = true
    suspend fun setAlarmEnabled(token:String, cameraId:String, enabled:Boolean): Boolean = true
    suspend fun startSiren(token:String, cameraId:String): Boolean = true
    suspend fun downloadLastAlarmImage(token:String, cameraId:String): ByteArray? = null
}

data class Camera(val id:String, val name:String, val pirEnabled:Boolean, val alarmEnabled:Boolean)
