package com.example.cloudedge4tasker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel()
            Surface(color = MaterialTheme.colors.background) {
                MainScreen(vm)
            }
        }
    }
}

@Composable
fun MainScreen(vm: MainViewModel) {
    val state by vm.uiState.collectAsState()
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("CloudEdge4Tasker — Lite", style = MaterialTheme.typography.h6)
        Spacer(Modifier.height(12.dp))
        if (!state.logged) {
            LoginBlock(onLogin = { country, prefix, email, pw -> vm.login(country, prefix, email, pw) })
        } else {
            CameraList(cameras = state.cameras, onToggleMotion = { cam, enabled -> vm.setMotion(cam.id, enabled) }, onDownload = { vm.downloadLastImage(it.id) })
        }
    }
}

@Composable
fun LoginBlock(onLogin: (String, String, String, String) -> Unit) {
    var email by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    Button(onClick = { onLogin("us","+1",email,pw) }) {
        Text("Se connecter (démo)")
    }
}

@Composable
fun CameraList(cameras: List<Camera>, onToggleMotion: (Camera, Boolean) -> Unit, onDownload: (Camera) -> Unit) {
    Column {
        cameras.forEach { cam ->
            Card(modifier = Modifier.fillMaxWidth().padding(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(cam.name)
                        Text("ID: ${cam.id}", style = MaterialTheme.typography.caption)
                    }
                    Switch(checked = cam.pirEnabled, onCheckedChange = { onToggleMotion(cam, it) })
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { onDownload(cam) }) {
                        Text("Télécharger")
                    }
                }
            }
        }
    }
}
